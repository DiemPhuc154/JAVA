package com.cybersoft.crm.service;

import com.cybersoft.crm.model.UsersModel;
import com.cybersoft.crm.repository.UserRepository;

import java.util.List;

public class LoginService {
    UserRepository userRepository = new UserRepository();
    public boolean checkLogin(String email, String password){
        List<UsersModel> list = userRepository.getUsersByEmailAndPassword(email, password);
        for (UsersModel usersModel : list){
            System.out.println(usersModel.getFullname());
        }
        if(list.size() > 0){
            return true;
        } else {
            return false;
        }
    }
}
