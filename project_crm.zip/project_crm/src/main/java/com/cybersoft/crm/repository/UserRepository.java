package com.cybersoft.crm.repository;

import com.cybersoft.crm.config.MysqlConnection;
import com.cybersoft.crm.model.UsersModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UserRepository {
    //doi vs cau select lay gia tri: excuteQuery
    // doi vs nhung cau insert update, delete: exucteUpdate
    public List<UsersModel> getUsersByEmailAndPassword(String email, String password){
        List<UsersModel> list = new ArrayList<>();
        try{
            String query = "select * from users u where u.email = ? and u.password = ?";
            Connection connection = MysqlConnection.getConnection();
            PreparedStatement prepareStatement = connection.prepareStatement(query);
            prepareStatement.setString(1, email);
            prepareStatement.setString(2, password);

            ResultSet resultSet = prepareStatement.executeQuery();
            while(resultSet.next()){
                UsersModel usersModel = new UsersModel();
                usersModel.setId(resultSet.getInt("id"));
                usersModel.setEmail(resultSet.getString("email"));
                usersModel.setAvatar(resultSet.getString("avatar"));
                usersModel.setFullname(resultSet.getString("fullname"));
                usersModel.setRoleId(resultSet.getInt("role_id"));
                list.add(usersModel);
            }
            connection.close();;
        } catch (Exception e){
            System.out.println("Error getUsersByEmailAndPassword " + e.getMessage());
        }
       return  list;
    }
}
